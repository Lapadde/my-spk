<?php
session_start();
require_once '../db/config.php';

// Cek apakah user sudah login dan memiliki role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.html");
    exit();
}

// Mengambil statistik untuk dashboard
$stats = [
    'total_dosen' => 0,
    'total_penilai' => 0,
    'total_kriteria' => 0,
    'total_penilaian' => 0
];

// Hitung total dosen
$query = "SELECT COUNT(*) as total FROM dosen";
$result = $conn->query($query);
if ($result) {
    $stats['total_dosen'] = $result->fetch_assoc()['total'];
}

// Hitung total penilai
$query = "SELECT COUNT(*) as total FROM users WHERE role = 'penilai' AND is_active = 1";
$result = $conn->query($query);
if ($result) {
    $stats['total_penilai'] = $result->fetch_assoc()['total'];
}

// Hitung total kriteria
$query = "SELECT COUNT(*) as total FROM kriteria";
$result = $conn->query($query);
if ($result) {
    $stats['total_kriteria'] = $result->fetch_assoc()['total'];
}

// Hitung total penilaian
$query = "SELECT COUNT(*) as total FROM penilaian";
$result = $conn->query($query);
if ($result) {
    $stats['total_penilaian'] = $result->fetch_assoc()['total'];
}

// Mengambil data dosen terbaik
$query = "SELECT d.nama, d.nip, h.total_nilai, h.peringkat 
          FROM hasil_akhir h 
          JOIN dosen d ON h.dosen_id = d.id 
          WHERE h.tahun_akademik = '2023/2024' 
          AND h.semester = 'Ganjil' 
          ORDER BY h.peringkat ASC 
          LIMIT 5";
$top_dosen = $conn->query($query);

// Mengambil data untuk chart distribusi nilai
$query = "SELECT 
            CASE 
                WHEN p.nilai >= 90 THEN 'Sangat Baik (90-100)'
                WHEN p.nilai >= 80 THEN 'Baik (80-89)'
                WHEN p.nilai >= 70 THEN 'Cukup (70-79)'
                WHEN p.nilai >= 60 THEN 'Kurang (60-69)'
                ELSE 'Sangat Kurang (<60)'
            END as kategori,
            COUNT(*) as jumlah
          FROM penilaian p
          GROUP BY kategori
          ORDER BY MIN(p.nilai) DESC";
$distribusi_nilai = $conn->query($query);

// Mengambil data untuk chart penilaian per kriteria
$query = "SELECT k.nama_kriteria, AVG(p.nilai) as rata_nilai
          FROM penilaian p
          JOIN kriteria k ON p.kriteria_id = k.id
          GROUP BY k.id, k.nama_kriteria
          ORDER BY k.id";
$nilai_kriteria = $conn->query($query);

// Mengambil data untuk chart penilaian per fakultas
$query = "SELECT d.fakultas, AVG(p.nilai) as rata_nilai
          FROM penilaian p
          JOIN dosen d ON p.dosen_id = d.id
          GROUP BY d.fakultas
          ORDER BY rata_nilai DESC";
$nilai_fakultas = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - SPK Dosen Terbaik</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2c3e50;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        .sidebar {
            background: var(--secondary-color);
            min-height: 100vh;
            color: white;
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,.8);
            padding: 1rem;
            margin: 0.2rem 0;
            border-radius: 0.25rem;
        }
        
        .sidebar .nav-link:hover {
            background: rgba(255,255,255,.1);
            color: white;
        }
        
        .sidebar .nav-link.active {
            background: var(--primary-color);
            color: white;
        }
        
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .stat-card {
            transition: transform 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-icon {
            font-size: 2rem;
            opacity: 0.8;
        }

        .no-data-message {
            text-align: center;
            padding: 2rem;
            color: #6c757d;
        }

        .no-data-message i {
            font-size: 3rem;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 sidebar">
                <div class="p-3">
                    <h4 class="text-center mb-4">
                        <i class="fas fa-chalkboard-teacher me-2"></i>
                        SPK Dosen
                    </h4>
                    <hr>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="dashboard.php">
                                <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="dosen.php">
                                <i class="fas fa-user-tie me-2"></i>Dosen
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="kriteria.php">
                                <i class="fas fa-list me-2"></i>Kriteria
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="penilaian.php">
                                <i class="fas fa-star me-2"></i>Penilaian
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="hasil.php">
                                <i class="fas fa-chart-bar me-2"></i>Hasil
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="users.php">
                                <i class="fas fa-users me-2"></i>Users
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">
                                <i class="fas fa-user-cog me-2"></i>Profil
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="backup.php">
                                <i class="fas fa-database me-2"></i>Backup
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="log_activity.php">
                                <i class="fas fa-history me-2"></i>Log Aktivitas
                            </a>
                        </li>
                        <li class="nav-item mt-4">
                            <a class="nav-link text-danger" href="../logout.php">
                                <i class="fas fa-sign-out-alt me-2"></i>Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Dashboard</h2>
                    <div class="user-info">
                        <span class="me-2">Selamat datang, <?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                        <img src="https://via.placeholder.com/40" class="rounded-circle" alt="Profile">
                    </div>
                </div>

                <!-- Statistics Cards -->
                <div class="row g-4 mb-4">
                    <div class="col-md-3">
                        <div class="card stat-card bg-primary text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title">Total Dosen</h6>
                                        <h2 class="mb-0"><?php echo $stats['total_dosen']; ?></h2>
                                    </div>
                                    <i class="fas fa-user-tie stat-icon"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card bg-success text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title">Total Penilai</h6>
                                        <h2 class="mb-0"><?php echo $stats['total_penilai']; ?></h2>
                                    </div>
                                    <i class="fas fa-users stat-icon"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card bg-info text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title">Kriteria</h6>
                                        <h2 class="mb-0"><?php echo $stats['total_kriteria']; ?></h2>
                                    </div>
                                    <i class="fas fa-list stat-icon"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card bg-warning text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title">Total Penilaian</h6>
                                        <h2 class="mb-0"><?php echo $stats['total_penilaian']; ?></h2>
                                    </div>
                                    <i class="fas fa-star stat-icon"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Charts Row -->
                <div class="row g-4 mb-4">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Distribusi Nilai Dosen</h5>
                                <?php if ($distribusi_nilai && $distribusi_nilai->num_rows > 0): ?>
                                    <canvas id="nilaiChart"></canvas>
                                <?php else: ?>
                                    <div class="no-data-message">
                                        <i class="fas fa-chart-bar"></i>
                                        <h5>Belum ada data penilaian</h5>
                                        <p>Silakan tambahkan data penilaian terlebih dahulu</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Dosen Terbaik</h5>
                                <?php if ($top_dosen && $top_dosen->num_rows > 0): ?>
                                    <div class="list-group">
                                        <?php while ($dosen = $top_dosen->fetch_assoc()): ?>
                                            <div class="list-group-item">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div>
                                                        <h6 class="mb-1"><?php echo htmlspecialchars($dosen['nama']); ?></h6>
                                                        <small class="text-muted"><?php echo htmlspecialchars($dosen['nip']); ?></small>
                                                    </div>
                                                    <span class="badge bg-primary rounded-pill">
                                                        <?php echo number_format($dosen['total_nilai'], 2); ?>
                                                    </span>
                                                </div>
                                            </div>
                                        <?php endwhile; ?>
                                    </div>
                                <?php else: ?>
                                    <div class="no-data-message">
                                        <i class="fas fa-trophy"></i>
                                        <h5>Belum ada data hasil</h5>
                                        <p>Silakan lakukan penilaian terlebih dahulu</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Additional Charts Row -->
                <div class="row g-4">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Rata-rata Nilai per Kriteria</h5>
                                <?php if ($nilai_kriteria && $nilai_kriteria->num_rows > 0): ?>
                                    <canvas id="kriteriaChart"></canvas>
                                <?php else: ?>
                                    <div class="no-data-message">
                                        <i class="fas fa-chart-line"></i>
                                        <h5>Belum ada data penilaian</h5>
                                        <p>Silakan tambahkan data penilaian terlebih dahulu</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Rata-rata Nilai per Fakultas</h5>
                                <?php if ($nilai_fakultas && $nilai_fakultas->num_rows > 0): ?>
                                    <canvas id="fakultasChart"></canvas>
                                <?php else: ?>
                                    <div class="no-data-message">
                                        <i class="fas fa-chart-pie"></i>
                                        <h5>Belum ada data penilaian</h5>
                                        <p>Silakan tambahkan data penilaian terlebih dahulu</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        // Data untuk chart distribusi nilai
        <?php if ($distribusi_nilai && $distribusi_nilai->num_rows > 0): ?>
        const nilaiData = {
            labels: [
                <?php 
                $distribusi_nilai->data_seek(0);
                while ($row = $distribusi_nilai->fetch_assoc()) {
                    echo "'" . $row['kategori'] . "',";
                }
                ?>
            ],
            datasets: [{
                label: 'Jumlah Dosen',
                data: [
                    <?php 
                    $distribusi_nilai->data_seek(0);
                    while ($row = $distribusi_nilai->fetch_assoc()) {
                        echo $row['jumlah'] . ",";
                    }
                    ?>
                ],
                backgroundColor: [
                    'rgba(40, 167, 69, 0.8)',
                    'rgba(23, 162, 184, 0.8)',
                    'rgba(255, 193, 7, 0.8)',
                    'rgba(220, 53, 69, 0.8)',
                    'rgba(108, 117, 125, 0.8)'
                ]
            }]
        };

        new Chart(document.getElementById('nilaiChart'), {
            type: 'bar',
            data: nilaiData,
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });
        <?php endif; ?>

        // Data untuk chart kriteria
        <?php if ($nilai_kriteria && $nilai_kriteria->num_rows > 0): ?>
        const kriteriaData = {
            labels: [
                <?php 
                $nilai_kriteria->data_seek(0);
                while ($row = $nilai_kriteria->fetch_assoc()) {
                    echo "'" . $row['nama_kriteria'] . "',";
                }
                ?>
            ],
            datasets: [{
                label: 'Rata-rata Nilai',
                data: [
                    <?php 
                    $nilai_kriteria->data_seek(0);
                    while ($row = $nilai_kriteria->fetch_assoc()) {
                        echo number_format($row['rata_nilai'], 2) . ",";
                    }
                    ?>
                ],
                backgroundColor: 'rgba(52, 152, 219, 0.8)',
                borderColor: 'rgba(52, 152, 219, 1)',
                borderWidth: 1
            }]
        };

        new Chart(document.getElementById('kriteriaChart'), {
            type: 'bar',
            data: kriteriaData,
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
        <?php endif; ?>

        // Data untuk chart fakultas
        <?php if ($nilai_fakultas && $nilai_fakultas->num_rows > 0): ?>
        const fakultasData = {
            labels: [
                <?php 
                $nilai_fakultas->data_seek(0);
                while ($row = $nilai_fakultas->fetch_assoc()) {
                    echo "'" . $row['fakultas'] . "',";
                }
                ?>
            ],
            datasets: [{
                label: 'Rata-rata Nilai',
                data: [
                    <?php 
                    $nilai_fakultas->data_seek(0);
                    while ($row = $nilai_fakultas->fetch_assoc()) {
                        echo number_format($row['rata_nilai'], 2) . ",";
                    }
                    ?>
                ],
                backgroundColor: [
                    'rgba(52, 152, 219, 0.8)',
                    'rgba(40, 167, 69, 0.8)',
                    'rgba(255, 193, 7, 0.8)',
                    'rgba(220, 53, 69, 0.8)',
                    'rgba(108, 117, 125, 0.8)'
                ]
            }]
        };

        new Chart(document.getElementById('fakultasChart'), {
            type: 'pie',
            data: fakultasData,
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'right'
                    }
                }
            }
        });
        <?php endif; ?>
    </script>
</body>
</html> 