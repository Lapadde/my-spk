<?php
session_start();
require_once '../db/config.php';

// Cek apakah user sudah login dan memiliki role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.html");
    exit();
}

// Inisialisasi variabel untuk menyimpan hasil query
$result = null;
$result_dosen = null;
$result_kriteria = null;
$result_fakultas = null;

// Cek apakah tabel yang diperlukan sudah ada
$tables_exist = true;
$required_tables = ['penilaian', 'dosen', 'kriteria', 'users'];
foreach ($required_tables as $table) {
    $check_table = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check_table->num_rows == 0) {
        $tables_exist = false;
        break;
    }
}

if ($tables_exist) {
    // Query untuk mengambil data penilaian
    $query = "SELECT p.*, d.nama as nama_dosen, k.nama_kriteria, u.username as nama_evaluator 
              FROM penilaian p 
              LEFT JOIN dosen d ON p.dosen_id = d.id 
              LEFT JOIN kriteria k ON p.kriteria_id = k.id 
              LEFT JOIN users u ON p.evaluator_id = u.id 
              ORDER BY p.tahun_akademik DESC, p.semester DESC, d.nama ASC";
    $result = $conn->query($query);

    // Query untuk mengambil data dosen
    $query_dosen = "SELECT * FROM dosen ORDER BY nama ASC";
    $result_dosen = $conn->query($query_dosen);

    // Query untuk mengambil data kriteria
    $query_kriteria = "SELECT * FROM kriteria ORDER BY id ASC";
    $result_kriteria = $conn->query($query_kriteria);

    // Query untuk mengambil data fakultas
    $query_fakultas = "SELECT DISTINCT fakultas FROM dosen ORDER BY fakultas ASC";
    $result_fakultas = $conn->query($query_fakultas);
}

// Proses hapus penilaian
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    if ($tables_exist) {
        $id = $_GET['delete'];
        $query = "DELETE FROM penilaian WHERE id = ?";
        $stmt = $conn->prepare($query);
        if ($stmt) {
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) {
                $_SESSION['success'] = "Data penilaian berhasil dihapus!";
            } else {
                $_SESSION['error'] = "Gagal menghapus data penilaian!";
            }
        }
    }
    header("Location: penilaian.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Penilaian Dosen - SPK Dosen Terbaik</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- DataTables CSS -->
    <link href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2c3e50;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        .sidebar {
            background: var(--secondary-color);
            min-height: 100vh;
            color: white;
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,.8);
            padding: 1rem;
            margin: 0.2rem 0;
            border-radius: 0.25rem;
        }
        
        .sidebar .nav-link:hover {
            background: rgba(255,255,255,.1);
            color: white;
        }
        
        .sidebar .nav-link.active {
            background: var(--primary-color);
            color: white;
        }
        
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: #2980b9;
            border-color: #2980b9;
        }
        
        .table th {
            background-color: #f8f9fa;
        }

        .filter-section {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }

        .no-data-message {
            text-align: center;
            padding: 2rem;
            color: #6c757d;
        }

        .no-data-message i {
            font-size: 3rem;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 sidebar">
                <div class="p-3">
                    <h4 class="text-center mb-4">
                        <i class="fas fa-chalkboard-teacher me-2"></i>
                        SPK Dosen
                    </h4>
                    <hr>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">
                                <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="dosen.php">
                                <i class="fas fa-user-tie me-2"></i>Dosen
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="kriteria.php">
                                <i class="fas fa-list me-2"></i>Kriteria
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="penilaian.php">
                                <i class="fas fa-star me-2"></i>Penilaian
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="hasil.php">
                                <i class="fas fa-chart-bar me-2"></i>Hasil
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="users.php">
                                <i class="fas fa-users me-2"></i>Users
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">
                                <i class="fas fa-user-cog me-2"></i>Profil
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="backup.php">
                                <i class="fas fa-database me-2"></i>Backup
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="log_activity.php">
                                <i class="fas fa-history me-2"></i>Log Aktivitas
                            </a>
                        </li>
                        <li class="nav-item mt-4">
                            <a class="nav-link text-danger" href="../logout.php">
                                <i class="fas fa-sign-out-alt me-2"></i>Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Penilaian Dosen</h2>
                    <?php if ($tables_exist): ?>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addPenilaianModal">
                        <i class="fas fa-plus me-2"></i>Tambah Penilaian
                    </button>
                    <?php endif; ?>
                </div>

                <?php if (!$tables_exist): ?>
                <div class="alert alert-warning" role="alert">
                    <h4 class="alert-heading"><i class="fas fa-exclamation-triangle me-2"></i>Database Belum Siap</h4>
                    <p>Beberapa tabel yang diperlukan belum tersedia dalam database. Silakan pastikan Anda telah:</p>
                    <ol>
                        <li>Membuat database dengan nama <code>my-spk</code></li>
                        <li>Mengimpor struktur tabel dari file <code>database.sql</code></li>
                        <li>Memastikan semua tabel yang diperlukan sudah dibuat:
                            <ul>
                                <li>penilaian</li>
                                <li>dosen</li>
                                <li>kriteria</li>
                                <li>users</li>
                            </ul>
                        </li>
                    </ol>
                    <hr>
                    <p class="mb-0">Setelah database siap, silakan refresh halaman ini.</p>
                </div>
                <?php else: ?>
                <!-- Filter Section -->
                <div class="filter-section">
                    <form method="GET" class="row">
                        <div class="col-md-3 mb-3">
                            <label for="fakultas" class="form-label">Fakultas</label>
                            <select class="form-select" id="fakultas" name="fakultas">
                                <option value="">Semua Fakultas</option>
                                <?php while ($row = $result_fakultas->fetch_assoc()): ?>
                                <option value="<?php echo htmlspecialchars($row['fakultas']); ?>">
                                    <?php echo htmlspecialchars($row['fakultas']); ?>
                                </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="kriteria" class="form-label">Kriteria</label>
                            <select class="form-select" id="kriteria" name="kriteria">
                                <option value="">Semua Kriteria</option>
                                <?php 
                                $result_kriteria->data_seek(0);
                                while ($row = $result_kriteria->fetch_assoc()): 
                                ?>
                                <option value="<?php echo $row['id']; ?>">
                                    <?php echo htmlspecialchars($row['nama_kriteria']); ?>
                                </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="tahun" class="form-label">Tahun Akademik</label>
                            <select class="form-select" id="tahun" name="tahun">
                                <option value="">Semua Tahun</option>
                                <option value="2023/2024">2023/2024</option>
                                <option value="2022/2023">2022/2023</option>
                            </select>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="semester" class="form-label">Semester</label>
                            <select class="form-select" id="semester" name="semester">
                                <option value="">Semua Semester</option>
                                <option value="Ganjil">Ganjil</option>
                                <option value="Genap">Genap</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary">Filter</button>
                            <a href="penilaian.php" class="btn btn-secondary">Reset</a>
                        </div>
                    </form>
                </div>

                <!-- Penilaian Table -->
                <div class="card">
                    <div class="card-body">
                        <?php if ($result && $result->num_rows > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover" id="penilaianTable">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Dosen</th>
                                        <th>Kriteria</th>
                                        <th>Nilai</th>
                                        <th>Evaluator</th>
                                        <th>Tahun Akademik</th>
                                        <th>Semester</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $no = 1;
                                    while ($row = $result->fetch_assoc()): 
                                    ?>
                                    <tr>
                                        <td><?php echo $no++; ?></td>
                                        <td><?php echo htmlspecialchars($row['nama_dosen']); ?></td>
                                        <td><?php echo htmlspecialchars($row['nama_kriteria']); ?></td>
                                        <td><?php echo $row['nilai']; ?></td>
                                        <td><?php echo htmlspecialchars($row['nama_evaluator']); ?></td>
                                        <td><?php echo htmlspecialchars($row['tahun_akademik']); ?></td>
                                        <td><?php echo htmlspecialchars($row['semester']); ?></td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-warning edit-penilaian" 
                                                    data-id="<?php echo $row['id']; ?>"
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#editPenilaianModal">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <a href="?delete=<?php echo $row['id']; ?>" 
                                               class="btn btn-sm btn-danger"
                                               onclick="return confirm('Apakah Anda yakin ingin menghapus penilaian ini?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php else: ?>
                        <div class="no-data-message">
                            <i class="fas fa-table"></i>
                            <h5>Belum ada data penilaian</h5>
                            <p>Silakan tambahkan data penilaian terlebih dahulu</p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Add Penilaian Modal -->
    <div class="modal fade" id="addPenilaianModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Tambah Penilaian</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form action="process_penilaian.php" method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="dosen_id" class="form-label">Dosen</label>
                            <select class="form-select" id="dosen_id" name="dosen_id" required>
                                <option value="">Pilih Dosen</option>
                                <?php 
                                $result_dosen->data_seek(0);
                                while ($row = $result_dosen->fetch_assoc()): 
                                ?>
                                <option value="<?php echo $row['id']; ?>">
                                    <?php echo htmlspecialchars($row['nama'] . ' (' . $row['nip'] . ')'); ?>
                                </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="kriteria_id" class="form-label">Kriteria</label>
                            <select class="form-select" id="kriteria_id" name="kriteria_id" required>
                                <option value="">Pilih Kriteria</option>
                                <?php 
                                $result_kriteria->data_seek(0);
                                while ($row = $result_kriteria->fetch_assoc()): 
                                ?>
                                <option value="<?php echo $row['id']; ?>">
                                    <?php echo htmlspecialchars($row['nama_kriteria']); ?>
                                </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="nilai" class="form-label">Nilai (0-100)</label>
                            <input type="number" class="form-control" id="nilai" name="nilai" 
                                   min="0" max="100" required>
                        </div>
                        <div class="mb-3">
                            <label for="tahun_akademik" class="form-label">Tahun Akademik</label>
                            <select class="form-select" id="tahun_akademik" name="tahun_akademik" required>
                                <option value="2023/2024">2023/2024</option>
                                <option value="2022/2023">2022/2023</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="semester" class="form-label">Semester</label>
                            <select class="form-select" id="semester" name="semester" required>
                                <option value="Ganjil">Ganjil</option>
                                <option value="Genap">Genap</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Penilaian Modal -->
    <div class="modal fade" id="editPenilaianModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Penilaian</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form action="process_penilaian.php" method="POST">
                    <input type="hidden" name="id" id="edit_id">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="edit_dosen_id" class="form-label">Dosen</label>
                            <select class="form-select" id="edit_dosen_id" name="dosen_id" required>
                                <option value="">Pilih Dosen</option>
                                <?php 
                                $result_dosen->data_seek(0);
                                while ($row = $result_dosen->fetch_assoc()): 
                                ?>
                                <option value="<?php echo $row['id']; ?>">
                                    <?php echo htmlspecialchars($row['nama'] . ' (' . $row['nip'] . ')'); ?>
                                </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="edit_kriteria_id" class="form-label">Kriteria</label>
                            <select class="form-select" id="edit_kriteria_id" name="kriteria_id" required>
                                <option value="">Pilih Kriteria</option>
                                <?php 
                                $result_kriteria->data_seek(0);
                                while ($row = $result_kriteria->fetch_assoc()): 
                                ?>
                                <option value="<?php echo $row['id']; ?>">
                                    <?php echo htmlspecialchars($row['nama_kriteria']); ?>
                                </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="edit_nilai" class="form-label">Nilai (0-100)</label>
                            <input type="number" class="form-control" id="edit_nilai" name="nilai" 
                                   min="0" max="100" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_tahun_akademik" class="form-label">Tahun Akademik</label>
                            <select class="form-select" id="edit_tahun_akademik" name="tahun_akademik" required>
                                <option value="2023/2024">2023/2024</option>
                                <option value="2022/2023">2022/2023</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="edit_semester" class="form-label">Semester</label>
                            <select class="form-select" id="edit_semester" name="semester" required>
                                <option value="Ganjil">Ganjil</option>
                                <option value="Genap">Genap</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>

    <script>
        $(document).ready(function() {
            // Inisialisasi DataTable
            $('#penilaianTable').DataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.11.5/i18n/id.json"
                }
            });

            // Handle edit button click
            $('.edit-penilaian').click(function() {
                var id = $(this).data('id');
                // Ajax request untuk mengambil data penilaian
                $.ajax({
                    url: 'get_penilaian.php',
                    type: 'POST',
                    data: {id: id},
                    dataType: 'json',
                    success: function(response) {
                        $('#edit_id').val(response.id);
                        $('#edit_dosen_id').val(response.dosen_id);
                        $('#edit_kriteria_id').val(response.kriteria_id);
                        $('#edit_nilai').val(response.nilai);
                        $('#edit_tahun_akademik').val(response.tahun_akademik);
                        $('#edit_semester').val(response.semester);
                    }
                });
            });
        });
    </script>
</body>
</html>